# spring-boot-security-oauth2-example
How to enable oauth2 in spring boot application
